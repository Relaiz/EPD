#!/usr/bin/env bash
# setup-ubuntu.sh — instalace závislostí pro Ubuntu 18.04+
set -euo pipefail

# Kontrola práv roota
if [[ $(id -u) -ne 0 ]]; then
  echo "Tento skript je třeba spustit jako root:"
  echo "  sudo $0"
  exit 1
fi

# Ověření, že jde o Ubuntu
. /etc/os-release
if [[ "$ID" != "ubuntu" ]]; then
  echo "Chyba: tento skript je určen pouze pro Ubuntu."
  exit 1
fi

CODENAME=$(lsb_release -cs)
echo "==> Zjištěno Ubuntu $VERSION ($CODENAME)"

echo "==> Aktualizuji seznam balíčků…"
apt-get update

echo "==> Instalace základních nástrojů…"
apt-get install -y \
    apt-transport-https \
    ca-certificates \
    gnupg \
    lsb-release \
    wget \
    curl

echo "==> Přidávám Microsoft repozitář pro .NET…"
wget -q "https://packages.microsoft.com/config/ubuntu/${CODENAME}/packages-microsoft-prod.deb" \
     -O /tmp/packages-microsoft-prod.deb
dpkg -i /tmp/packages-microsoft-prod.deb
rm /tmp/packages-microsoft-prod.deb

echo "==> Instalace .NET Runtime 8.0…"
apt-get update
apt-get install -y dotnet-runtime-8.0

echo "==> Instalace závislostí pro Avalonia GUI…"
apt-get install -y \
    libgtk-3-0 \
    libgtk-4-1 \
    libgdk-pixbuf2.0-0 \
    libxtst6 \
    libxss1 \
    libnss3 \
    libxinerama1 \
    libxcursor1 \
    libxrandr2

echo "==> Instalace Ghostscript pro náhled PDF…"
apt-get install -y ghostscript libgs-dev

echo "==> Instalace libgdiplus pro System.Drawing.Common…"
apt-get install -y libgdiplus

echo "==> Instalace SQLite…"
apt-get install -y sqlite3 libsqlite3-dev

echo
echo "✔ Všechny závislosti byly nainstalovány! Nyní můžete:"
echo "    dotnet build"
echo "    dotnet run"